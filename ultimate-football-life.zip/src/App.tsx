import React, { useState, useEffect } from 'react';
import { GameState, Player, MatchSimStats, BankTransaction, Contract, Club, NPC, House, Car, FootgramPost, GameSettings } from './types/index.ts';
import { createInitialGameState, INITIAL_CLUBS } from './utils/defaultData.ts';
import { saveGame, loadGame } from './utils/saveSystem.ts';
import { sounds } from './utils/audio.ts';

// View Components
import { TitleScreen } from './components/TitleScreen.tsx';
import { CharacterCreator } from './components/CharacterCreator.tsx';
import { Dashboard } from './components/Dashboard.tsx';
import { MatchView } from './components/MatchView.tsx';
import { TrainingView } from './components/TrainingView.tsx';
import { ClubView } from './components/ClubView.tsx';
import { ContractsView } from './components/ContractsView.tsx';
import { TransfersView } from './components/TransfersView.tsx';
import { RelationshipsView } from './components/RelationshipsView.tsx';
import { HouseView } from './components/HouseView.tsx';
import { GarageView } from './components/GarageView.tsx';
import { FootgramView } from './components/FootgramView.tsx';
import { PressView } from './components/PressView.tsx';
import { FinanceView } from './components/FinanceView.tsx';
import { SettingsModal } from './components/SettingsModal.tsx';

type Screen =
  | 'title'
  | 'character_creator'
  | 'dashboard'
  | 'match'
  | 'training'
  | 'club'
  | 'contracts'
  | 'transfers'
  | 'relationships'
  | 'house'
  | 'garage'
  | 'footgram'
  | 'press'
  | 'finance';

export default function App() {
  const [gameState, setGameState] = useState<GameState>(() => createInitialGameState());
  const [screen, setScreen] = useState<Screen>(() => {
    if (typeof window !== 'undefined') {
      const urlParams = new URLSearchParams(window.location.search);
      if (urlParams.get('autostart') === '1') return 'dashboard';
    }
    return 'title';
  });
  const [hasSaveData, setHasSaveData] = useState<boolean>(false);
  const [showSettings, setShowSettings] = useState<boolean>(false);

  // Initialize and load save
  useEffect(() => {
    // Check for ?autostart=1 support for verification and headless mode
    const urlParams = new URLSearchParams(window.location.search);
    const autostart = urlParams.get('autostart');

    loadGame().then((saved) => {
      if (saved) {
        setGameState(saved);
        setHasSaveData(true);
        if (autostart === '1') {
          setScreen('dashboard');
        }
      } else {
        if (autostart === '1') {
          setScreen('dashboard');
        }
      }
    });
  }, []);

  // Sync document body state for Ultra Mode compliance
  useEffect(() => {
    if (screen === 'title') {
      document.body.dataset.state = 'title';
    } else if (screen === 'match') {
      document.body.dataset.state = 'playing';
    } else {
      document.body.dataset.state = 'dashboard';
    }
  }, [screen]);

  // Auto-save on gameState changes
  useEffect(() => {
    if (screen !== 'title' && screen !== 'character_creator') {
      saveGame(gameState);
    }
  }, [gameState, screen]);

  // Finish match handler
  const handleFinishMatch = (stats: MatchSimStats) => {
    const isWin = stats.homeScore > stats.awayScore;
    const isDraw = stats.homeScore === stats.awayScore;

    // Bonuses calculation
    let matchBonus = 0;
    if (isWin) matchBonus += gameState.currentContract.winBonus;
    matchBonus += stats.playerGoals * gameState.currentContract.goalBonus;
    matchBonus += stats.playerAssists * gameState.currentContract.assistBonus;

    const newTransactions: BankTransaction[] = [];
    if (matchBonus > 0) {
      newTransactions.push({
        id: `tx_match_${Date.now()}`,
        description: `Bónus de Jogo (${stats.playerGoals} Golos, ${isWin ? 'Vitória' : 'Empate'})`,
        amount: matchBonus,
        category: 'Bónus',
        date: gameState.calendar.currentDate
      });
    }

    const updatedPlayer: Player = {
      ...gameState.player,
      energy: Math.max(20, gameState.player.energy - 35),
      fame: Math.min(100, gameState.player.fame + (stats.playerGoals * 4) + (isWin ? 3 : 0)),
      followers: gameState.player.followers + (stats.playerGoals * 8000) + 1500,
      careerStats: {
        ...gameState.player.careerStats,
        matchesPlayed: gameState.player.careerStats.matchesPlayed + 1,
        goals: gameState.player.careerStats.goals + stats.playerGoals,
        assists: gameState.player.careerStats.assists + stats.playerAssists,
        playerOfTheMatch: gameState.player.careerStats.playerOfTheMatch + (stats.playerGoals >= 2 ? 1 : 0)
      }
    };

    // Add match news headline
    const newArticle = {
      id: `news_${Date.now()}`,
      headline: stats.playerGoals > 0
        ? `Golaço de ${updatedPlayer.kitName} sela resultado empolgante!`
        : `Partida disputada até ao apito final na Liga!`,
      snippet: `${gameState.clubs[gameState.currentClubId]?.name} enfrentou ${gameState.clubs[gameState.calendar.upcomingOpponentId]?.name} com nota ${stats.playerRating.toFixed(1)} do jovem craque.`,
      category: 'Partida' as const,
      date: gameState.calendar.currentDate,
      impact: isWin ? 'Moral no máximo e aplausos dos adeptos!' : 'Adeptos pedem reação no próximo jogo.'
    };

    setGameState((prev) => ({
      ...prev,
      player: updatedPlayer,
      bankBalance: prev.bankBalance + matchBonus,
      transactions: [...newTransactions, ...prev.transactions],
      news: [newArticle, ...prev.news],
      calendar: {
        ...prev.calendar,
        nextMatchDaysAway: 6 // 6 days until next match
      }
    }));

    setScreen('press'); // transition into post-match press interview!
  };

  // Advance Day handler
  const handleAdvanceDay = () => {
    sounds.playUiClick();

    setGameState((prev) => {
      const nextDays = prev.calendar.nextMatchDaysAway <= 0 ? 0 : prev.calendar.nextMatchDaysAway - 1;

      // Energy recovery (+20% per day rested)
      const restoredEnergy = Math.min(100, prev.player.energy + 20);

      // Check weekly salary payout (every 7 days or when nextDays === 0)
      let addedSalary = 0;
      const newTx: BankTransaction[] = [];
      if (nextDays === 0) {
        addedSalary = prev.currentContract.weeklySalary;
        newTx.push({
          id: `tx_wage_${Date.now()}`,
          description: `Depósito de Salário Semanal (${prev.currentContract.clubName})`,
          amount: addedSalary,
          category: 'Salário',
          date: prev.calendar.currentDate
        });
      }

      return {
        ...prev,
        player: {
          ...prev.player,
          energy: restoredEnergy
        },
        bankBalance: prev.bankBalance + addedSalary,
        transactions: [...newTx, ...prev.transactions],
        calendar: {
          ...prev.calendar,
          nextMatchDaysAway: nextDays
        }
      };
    });
  };

  const handleCreatePlayer = (newPlayer: Player) => {
    const freshState = createInitialGameState(newPlayer);
    setGameState(freshState);
    saveGame(freshState);
    setHasSaveData(true);
    setScreen('dashboard');
  };

  const currentClub = gameState.clubs[gameState.currentClubId] || Object.values(gameState.clubs)[0];
  const awayClub = gameState.clubs[gameState.calendar.upcomingOpponentId] || Object.values(gameState.clubs)[1];

  return (
    <div className="w-full min-h-screen bg-slate-950 font-sans text-slate-100">
      {screen === 'title' && (
        <TitleScreen
          hasSaveGame={hasSaveData}
          onContinue={() => setScreen('dashboard')}
          onNewGame={() => setScreen('character_creator')}
        />
      )}

      {screen === 'character_creator' && (
        <CharacterCreator
          onComplete={handleCreatePlayer}
          onBack={() => setScreen('title')}
        />
      )}

      {screen === 'dashboard' && (
        <Dashboard
          gameState={gameState}
          onNavigate={(v) => setScreen(v as Screen)}
          onPlayMatch={() => setScreen('match')}
          onAdvanceDay={handleAdvanceDay}
          onOpenSettings={() => setShowSettings(true)}
        />
      )}

      {screen === 'match' && (
        <MatchView
          player={gameState.player}
          homeClub={currentClub}
          awayClub={awayClub}
          onFinishMatch={handleFinishMatch}
          onExit={() => setScreen('dashboard')}
        />
      )}

      {screen === 'training' && (
        <TrainingView
          player={gameState.player}
          onUpdatePlayer={(p) => setGameState((prev) => ({ ...prev, player: p }))}
          onBack={() => setScreen('dashboard')}
        />
      )}

      {screen === 'club' && (
        <ClubView
          currentClub={currentClub}
          player={gameState.player}
          leagueStandings={gameState.leagueStandings}
          onBack={() => setScreen('dashboard')}
        />
      )}

      {screen === 'contracts' && (
        <ContractsView
          contract={gameState.currentContract}
          player={gameState.player}
          currentClub={currentClub}
          onUpdateContract={(c) => setGameState((prev) => ({ ...prev, currentContract: c }))}
          onBack={() => setScreen('dashboard')}
        />
      )}

      {screen === 'transfers' && (
        <TransfersView
          player={gameState.player}
          currentClub={currentClub}
          clubs={gameState.clubs}
          onAcceptTransfer={(newClub, newContract) => {
            setGameState((prev) => ({
              ...prev,
              currentClubId: newClub.id,
              currentContract: newContract,
              bankBalance: prev.bankBalance + newContract.signingBonus,
              transactions: [
                {
                  id: `tx_sign_${Date.now()}`,
                  description: `Bónus de Assinatura: ${newClub.name}`,
                  amount: newContract.signingBonus,
                  category: 'Bónus',
                  date: prev.calendar.currentDate
                },
                ...prev.transactions
              ],
              player: {
                ...prev.player,
                appearance: {
                  ...prev.player.appearance,
                  kitPrimaryColor: newClub.primaryColor,
                  kitSecondaryColor: newClub.secondaryColor
                }
              }
            }));
            setScreen('dashboard');
          }}
          onBack={() => setScreen('dashboard')}
        />
      )}

      {screen === 'relationships' && (
        <RelationshipsView
          npcs={gameState.relationships}
          bankBalance={gameState.bankBalance}
          onUpdateNpcs={(updated, newBalance, newTx) => {
            setGameState((prev) => ({
              ...prev,
              relationships: updated,
              bankBalance: newBalance,
              transactions: newTx ? [newTx, ...prev.transactions] : prev.transactions
            }));
          }}
          onBack={() => setScreen('dashboard')}
        />
      )}

      {screen === 'house' && (
        <HouseView
          houses={gameState.houses}
          bankBalance={gameState.bankBalance}
          onUpdateHouses={(updated, newBalance, newTx) => {
            setGameState((prev) => ({
              ...prev,
              houses: updated,
              bankBalance: newBalance,
              transactions: newTx ? [newTx, ...prev.transactions] : prev.transactions
            }));
          }}
          onBack={() => setScreen('dashboard')}
        />
      )}

      {screen === 'garage' && (
        <GarageView
          cars={gameState.cars}
          bankBalance={gameState.bankBalance}
          onUpdateCars={(updated, newBalance, newTx) => {
            setGameState((prev) => ({
              ...prev,
              cars: updated,
              bankBalance: newBalance,
              transactions: newTx ? [newTx, ...prev.transactions] : prev.transactions
            }));
          }}
          onBack={() => setScreen('dashboard')}
        />
      )}

      {screen === 'footgram' && (
        <FootgramView
          player={gameState.player}
          posts={gameState.footgramPosts}
          onAddPost={(newPost) => {
            setGameState((prev) => ({
              ...prev,
              footgramPosts: [newPost, ...prev.footgramPosts],
              player: {
                ...prev.player,
                followers: prev.player.followers + Math.floor(newPost.likes * 0.4),
                fame: Math.min(100, prev.player.fame + 2)
              }
            }));
          }}
          onLikePost={(postId) => {
            setGameState((prev) => ({
              ...prev,
              footgramPosts: prev.footgramPosts.map((p) =>
                p.id === postId ? { ...p, playerLiked: !p.playerLiked, likes: p.likes + (p.playerLiked ? -1 : 1) } : p
              )
            }));
          }}
          onBack={() => setScreen('dashboard')}
        />
      )}

      {screen === 'press' && (
        <PressView
          player={gameState.player}
          news={gameState.news}
          onUpdatePlayer={(p) => setGameState((prev) => ({ ...prev, player: p }))}
          onBack={() => setScreen('dashboard')}
        />
      )}

      {screen === 'finance' && (
        <FinanceView
          bankBalance={gameState.bankBalance}
          transactions={gameState.transactions}
          houses={gameState.houses}
          cars={gameState.cars}
          contract={gameState.currentContract}
          onBack={() => setScreen('dashboard')}
        />
      )}

      {/* Settings Modal */}
      {showSettings && (
        <SettingsModal
          settings={gameState.settings}
          gameState={gameState}
          onUpdateSettings={(s: GameSettings) => setGameState((prev) => ({ ...prev, settings: s }))}
          onImportState={(s: GameState) => setGameState(s)}
          onResetGame={() => {
            const fresh = createInitialGameState();
            setGameState(fresh);
            saveGame(fresh);
            setShowSettings(false);
            setScreen('title');
          }}
          onClose={() => setShowSettings(false)}
        />
      )}
    </div>
  );
}
