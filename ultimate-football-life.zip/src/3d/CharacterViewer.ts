import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { PlayerAppearance } from '../types/index.ts';

export class CharacterViewer {
  private container: HTMLDivElement;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private characterGroup!: THREE.Group;
  private animFrameId: number = 0;
  private isDestroyed: boolean = false;
  private isDragging: boolean = false;
  private prevPointerX: number = 0;

  // Meshes for live dynamic re-coloring
  private skinMeshes: THREE.Mesh[] = [];
  private hairMeshes: THREE.Mesh[] = [];
  private jerseyMeshes: THREE.Mesh[] = [];
  private shortsMeshes: THREE.Mesh[] = [];
  private bootsMeshes: THREE.Mesh[] = [];

  constructor(container: HTMLDivElement, appearance: PlayerAppearance, kitNumber: number = 10) {
    this.container = container;
    this.init(appearance, kitNumber);
  }

  private init(app: PlayerAppearance, kitNumber: number) {
    const width = this.container.clientWidth || 300;
    const height = this.container.clientHeight || 400;

    this.scene = new THREE.Scene();
    this.scene.background = null; // transparent

    this.camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    this.camera.position.set(0, 1.4, 4.2);
    this.camera.lookAt(0, 1.2, 0);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.2;

    this.container.appendChild(this.renderer.domElement);

    // Environment
    try {
      const pmrem = new THREE.PMREMGenerator(this.renderer);
      this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
      pmrem.dispose();
    } catch {
      // ignore
    }

    // Lights
    const keyLight = new THREE.DirectionalLight(0xfffaed, 2.0);
    keyLight.position.set(3, 5, 4);
    this.scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x38bdf8, 1.5);
    rimLight.position.set(-3, 4, -3);
    this.scene.add(rimLight);

    const fillLight = new THREE.HemisphereLight(0xffffff, 0x1e293b, 1.0);
    this.scene.add(fillLight);

    // Pedestal Platform
    const pedestalGeo = new THREE.CylinderGeometry(1.2, 1.3, 0.15, 32);
    const pedestalMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.3, metalness: 0.7 });
    const pedestal = new THREE.Mesh(pedestalGeo, pedestalMat);
    pedestal.position.y = -0.075;
    this.scene.add(pedestal);

    const ringGeo = new THREE.RingGeometry(1.1, 1.18, 32);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b, side: THREE.DoubleSide });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.005;
    this.scene.add(ring);

    // Build Character Model
    this.characterGroup = new THREE.Group();
    this.buildModel(app, kitNumber);
    this.scene.add(this.characterGroup);

    this.setupControls();
    this.startLoop();
  }

  private buildModel(app: PlayerAppearance, kitNum: number) {
    this.skinMeshes = [];
    this.hairMeshes = [];
    this.jerseyMeshes = [];
    this.shortsMeshes = [];
    this.bootsMeshes = [];

    const skinMat = new THREE.MeshStandardMaterial({ color: app.skinTone || '#e0ac69', roughness: 0.8 });
    const hairMat = new THREE.MeshStandardMaterial({ color: app.hairColor || '#2b1d0c', roughness: 0.9 });
    const jerseyMat = new THREE.MeshStandardMaterial({ color: app.kitPrimaryColor || '#0284c7', roughness: 0.5 });
    const shortsMat = new THREE.MeshStandardMaterial({ color: app.kitSecondaryColor || '#ffffff', roughness: 0.5 });
    const bootsMat = new THREE.MeshStandardMaterial({ color: app.bootsColor || '#f59e0b', roughness: 0.3, metalness: 0.2 });

    // Torso
    const torsoGeo = new THREE.BoxGeometry(0.8, 1.0, 0.46);
    const torso = new THREE.Mesh(torsoGeo, jerseyMat);
    torso.position.y = 1.35;
    this.characterGroup.add(torso);
    this.jerseyMeshes.push(torso);

    // Head
    const headGeo = new THREE.BoxGeometry(0.52, 0.54, 0.52);
    const head = new THREE.Mesh(headGeo, skinMat);
    head.position.y = 2.12;
    this.characterGroup.add(head);
    this.skinMeshes.push(head);

    // Hair
    const hairGeo = new THREE.BoxGeometry(0.56, 0.25, 0.56);
    const hair = new THREE.Mesh(hairGeo, hairMat);
    hair.position.y = 2.42;
    this.characterGroup.add(hair);
    this.hairMeshes.push(hair);

    // Shorts
    const shortsGeo = new THREE.BoxGeometry(0.76, 0.46, 0.45);
    const shorts = new THREE.Mesh(shortsGeo, shortsMat);
    shorts.position.y = 0.88;
    this.characterGroup.add(shorts);
    this.shortsMeshes.push(shorts);

    // Legs
    const legGeo = new THREE.BoxGeometry(0.24, 0.78, 0.24);
    const leftLeg = new THREE.Mesh(legGeo, skinMat);
    leftLeg.position.set(-0.21, 0.44, 0);
    this.characterGroup.add(leftLeg);
    this.skinMeshes.push(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, skinMat);
    rightLeg.position.set(0.21, 0.44, 0);
    this.characterGroup.add(rightLeg);
    this.skinMeshes.push(rightLeg);

    // Boots
    const bootGeo = new THREE.BoxGeometry(0.26, 0.16, 0.42);
    const leftBoot = new THREE.Mesh(bootGeo, bootsMat);
    leftBoot.position.set(0, -0.4, 0.08);
    leftLeg.add(leftBoot);
    this.bootsMeshes.push(leftBoot);

    const rightBoot = new THREE.Mesh(bootGeo, bootsMat);
    rightBoot.position.set(0, -0.4, 0.08);
    rightLeg.add(rightBoot);
    this.bootsMeshes.push(rightBoot);

    // Arms
    const armGeo = new THREE.BoxGeometry(0.18, 0.72, 0.18);
    const leftArm = new THREE.Mesh(armGeo, skinMat);
    leftArm.position.set(-0.5, 1.3, 0);
    this.characterGroup.add(leftArm);
    this.skinMeshes.push(leftArm);

    const rightArm = new THREE.Mesh(armGeo, skinMat);
    rightArm.position.set(0.5, 1.3, 0);
    this.characterGroup.add(rightArm);
    this.skinMeshes.push(rightArm);
  }

  public updateAppearance(app: PlayerAppearance) {
    this.skinMeshes.forEach(m => (m.material as THREE.MeshStandardMaterial).color.set(app.skinTone));
    this.hairMeshes.forEach(m => (m.material as THREE.MeshStandardMaterial).color.set(app.hairColor));
    this.jerseyMeshes.forEach(m => (m.material as THREE.MeshStandardMaterial).color.set(app.kitPrimaryColor));
    this.shortsMeshes.forEach(m => (m.material as THREE.MeshStandardMaterial).color.set(app.kitSecondaryColor));
    this.bootsMeshes.forEach(m => (m.material as THREE.MeshStandardMaterial).color.set(app.bootsColor));
  }

  private setupControls() {
    const el = this.renderer.domElement;

    const onPointerDown = (e: MouseEvent | TouchEvent) => {
      this.isDragging = true;
      this.prevPointerX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    };

    const onPointerMove = (e: MouseEvent | TouchEvent) => {
      if (!this.isDragging) return;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const deltaX = clientX - this.prevPointerX;
      this.characterGroup.rotation.y += deltaX * 0.015;
      this.prevPointerX = clientX;
    };

    const onPointerUp = () => {
      this.isDragging = false;
    };

    el.addEventListener('mousedown', onPointerDown);
    window.addEventListener('mousemove', onPointerMove);
    window.addEventListener('mouseup', onPointerUp);

    el.addEventListener('touchstart', onPointerDown);
    window.addEventListener('touchmove', onPointerMove);
    window.addEventListener('touchend', onPointerUp);
  }

  private startLoop() {
    const tick = () => {
      if (this.isDestroyed) return;
      if (!this.isDragging) {
        this.characterGroup.rotation.y += 0.005; // gentle idle turntable rotation
      }
      this.renderer.render(this.scene, this.camera);
      this.animFrameId = requestAnimationFrame(tick);
    };
    this.animFrameId = requestAnimationFrame(tick);
  }

  public destroy() {
    this.isDestroyed = true;
    cancelAnimationFrame(this.animFrameId);
    if (this.renderer) {
      this.renderer.dispose();
      if (this.container && this.renderer.domElement) {
        this.container.removeChild(this.renderer.domElement);
      }
    }
  }
}
