import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Player, Club } from '../types/index.ts';
import { sounds } from '../utils/audio.ts';

export interface MatchInputState {
  joystickVector: { x: number; y: number }; // -1 to 1
  sprintHeld: boolean;
  shootCharge: number; // 0 to 1
  shootReleased: boolean;
  passRequested: boolean;
  dribbleRequested: boolean;
  tackleRequested: boolean;
  pressHeld: boolean;
}

export interface MatchSimStats {
  homeScore: number;
  awayScore: number;
  matchTimeMinutes: number; // 0 - 90
  playerGoals: number;
  playerAssists: number;
  playerShots: number;
  playerPasses: number;
  playerTackles: number;
  playerRating: number;
  isGameOver: boolean;
  latestEventMessage: string | null;
}

interface Actor3D {
  mesh: THREE.Group;
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  targetPos: THREE.Vector3;
  isHomeTeam: boolean;
  isPlayer: boolean;
  isGoalkeeper: boolean;
  role: 'GK' | 'DEF' | 'MID' | 'ATT';
  number: number;
  name: string;
  speed: number;
  kickCooldown: number;
  tackleTimer: number;
  animPhase: number;
  legs: [THREE.Mesh, THREE.Mesh];
  arms: [THREE.Mesh, THREE.Mesh];
  head: THREE.Mesh;
}

export class PitchGameEngine {
  public container: HTMLDivElement;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private isSoftwareGl: boolean = false;
  private animFrameId: number = 0;
  private isDestroyed: boolean = false;

  // Match entities
  private actors: Actor3D[] = [];
  public playerActor: Actor3D | null = null;
  private ballMesh!: THREE.Mesh;
  private ballPos: THREE.Vector3 = new THREE.Vector3(0, 0.22, 0);
  private ballVel: THREE.Vector3 = new THREE.Vector3(0, 0, 0);
  private ballSpin: THREE.Vector3 = new THREE.Vector3(0, 0, 0);
  private ballHolder: Actor3D | null = null;

  // Stadium & Pitch dimensions (standard pitch scale: 100m x 64m)
  private readonly PITCH_L = 84;
  private readonly PITCH_W = 54;
  private readonly GOAL_W = 7.32;
  private readonly GOAL_H = 2.44;

  // Match state
  public matchStats: MatchSimStats = {
    homeScore: 0,
    awayScore: 0,
    matchTimeMinutes: 0,
    playerGoals: 0,
    playerAssists: 0,
    playerShots: 0,
    playerPasses: 0,
    playerTackles: 0,
    playerRating: 6.8,
    isGameOver: false,
    latestEventMessage: 'Início da Partida! O árbitro apita.'
  };

  private homeClub: Club;
  private awayClub: Club;
  private userPlayer: Player;
  private onGoalScoredCallback: (scorerName: string, isUser: boolean) => void;
  private onMatchEndCallback: (stats: MatchSimStats) => void;
  public onStateUpdate?: (stats: MatchSimStats) => void;

  // Goal trigger cooldown
  private goalCooldown: number = 0;
  private matchTimerAccum: number = 0;
  private cameraTargetOffset: THREE.Vector3 = new THREE.Vector3(0, 12, 18);
  private cameraLookTarget: THREE.Vector3 = new THREE.Vector3(0, 0, 0);

  // Scratch vectors for zero GC in render loop
  private _vecA = new THREE.Vector3();
  private _vecB = new THREE.Vector3();
  private _vecC = new THREE.Vector3();

  constructor(
    container: HTMLDivElement,
    userPlayer: Player,
    homeClub: Club,
    awayClub: Club,
    onGoalScored: (scorerName: string, isUser: boolean) => void,
    onMatchEnd: (stats: MatchSimStats) => void
  ) {
    this.container = container;
    this.userPlayer = userPlayer;
    this.homeClub = homeClub;
    this.awayClub = awayClub;
    this.onGoalScoredCallback = onGoalScored;
    this.onMatchEndCallback = onMatchEnd;

    this.initWebGL();
    this.createEnvironment();
    this.createPitchAndStadium();
    this.createBall();
    this.spawnTeams();
    this.setupResizeListener();

    sounds.playWhistle(true);
    this.startLoop();
  }

  private initWebGL() {
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#0a1128');
    this.scene.fog = new THREE.FogExp2('#0a1128', 0.008);

    this.camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 400);
    this.camera.position.set(0, 16, 24);

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance'
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.container.appendChild(this.renderer.domElement);

    // Studio Reflection Environment
    try {
      const pmrem = new THREE.PMREMGenerator(this.renderer);
      this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
      pmrem.dispose();
    } catch {
      // Fallback if RoomEnv fails
    }
  }

  private createEnvironment() {
    // Warm key light (stadium floodlight)
    const keyLight = new THREE.DirectionalLight(0xfff5e6, 2.2);
    keyLight.position.set(30, 45, 25);
    keyLight.castShadow = !this.isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.camera.near = 10;
      keyLight.shadow.camera.far = 120;
      keyLight.shadow.camera.left = -this.PITCH_L / 2;
      keyLight.shadow.camera.right = this.PITCH_L / 2;
      keyLight.shadow.camera.top = this.PITCH_W / 2;
      keyLight.shadow.camera.bottom = -this.PITCH_W / 2;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    this.scene.add(keyLight);

    // Cool sky hemisphere fill
    const hemiLight = new THREE.HemisphereLight(0x7dd3fc, 0x14532d, 1.1);
    this.scene.add(hemiLight);

    // 4 Corner Stadium Floodlight Towers
    const cornerPositions = [
      [-this.PITCH_L / 2 - 8, -this.PITCH_W / 2 - 8],
      [this.PITCH_L / 2 + 8, -this.PITCH_W / 2 - 8],
      [-this.PITCH_L / 2 - 8, this.PITCH_W / 2 + 8],
      [this.PITCH_L / 2 + 8, this.PITCH_W / 2 + 8]
    ];

    const towerGeo = new THREE.CylinderGeometry(0.3, 0.6, 24, 8);
    const towerMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8, roughness: 0.3 });
    const lampGeo = new THREE.BoxGeometry(3, 1.2, 1);
    const lampMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

    cornerPositions.forEach(([x, z]) => {
      const tower = new THREE.Mesh(towerGeo, towerMat);
      tower.position.set(x, 12, z);
      this.scene.add(tower);

      const lamp = new THREE.Mesh(lampGeo, lampMat);
      lamp.position.set(x, 24, z);
      lamp.lookAt(0, 0, 0);
      this.scene.add(lamp);

      const spot = new THREE.SpotLight(0xfff1d6, 0.8, 80, Math.PI / 4, 0.4);
      spot.position.set(x, 24, z);
      spot.target.position.set(0, 0, 0);
      this.scene.add(spot);
      this.scene.add(spot.target);
    });
  }

  private createPitchTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d')!;

    // Base striped grass
    const stripes = 14;
    const stripeH = canvas.height / stripes;
    for (let i = 0; i < stripes; i++) {
      ctx.fillStyle = i % 2 === 0 ? '#1b6329' : '#1e7531';
      ctx.fillRect(0, i * stripeH, canvas.width, stripeH);
    }

    // White field markings
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 6;

    const pad = 40;
    const w = canvas.width - pad * 2;
    const h = canvas.height - pad * 2;

    // Outer touchlines
    ctx.strokeRect(pad, pad, w, h);

    // Halfway line
    ctx.beginPath();
    ctx.moveTo(canvas.width / 2, pad);
    ctx.lineTo(canvas.width / 2, canvas.height - pad);
    ctx.stroke();

    // Center circle
    ctx.beginPath();
    ctx.arc(canvas.width / 2, canvas.height / 2, 75, 0, Math.PI * 2);
    ctx.stroke();

    // Center spot
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(canvas.width / 2, canvas.height / 2, 5, 0, Math.PI * 2);
    ctx.fill();

    // Left Penalty Box
    const boxW = 140;
    const boxH = 260;
    const boxY = (canvas.height - boxH) / 2;
    ctx.strokeRect(pad, boxY, boxW, boxH);

    // Left Goal Area (6-yard)
    const goalBoxW = 55;
    const goalBoxH = 120;
    const goalBoxY = (canvas.height - goalBoxH) / 2;
    ctx.strokeRect(pad, goalBoxY, goalBoxW, goalBoxH);

    // Left Penalty Spot
    ctx.beginPath();
    ctx.arc(pad + 95, canvas.height / 2, 4, 0, Math.PI * 2);
    ctx.fill();

    // Right Penalty Box
    ctx.strokeRect(canvas.width - pad - boxW, boxY, boxW, boxH);
    // Right Goal Area
    ctx.strokeRect(canvas.width - pad - goalBoxW, goalBoxY, goalBoxW, goalBoxH);
    // Right Penalty Spot
    ctx.beginPath();
    ctx.arc(canvas.width - pad - 95, canvas.height / 2, 4, 0, Math.PI * 2);
    ctx.fill();

    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = this.renderer.capabilities.getMaxAnisotropy();
    return texture;
  }

  private createPitchAndStadium() {
    // 1. Grass Pitch Plane
    const pitchGeo = new THREE.PlaneGeometry(this.PITCH_L, this.PITCH_W);
    const pitchMat = new THREE.MeshStandardMaterial({
      map: this.createPitchTexture(),
      roughness: 0.85,
      metalness: 0.05
    });
    const pitchMesh = new THREE.Mesh(pitchGeo, pitchMat);
    pitchMesh.rotation.x = -Math.PI / 2;
    pitchMesh.receiveShadow = !this.isSoftwareGl;
    this.scene.add(pitchMesh);

    // 2. Surrounding apron / track
    const apronGeo = new THREE.PlaneGeometry(this.PITCH_L + 16, this.PITCH_W + 16);
    const apronMat = new THREE.MeshStandardMaterial({ color: 0x0f291e, roughness: 0.95 });
    const apronMesh = new THREE.Mesh(apronGeo, apronMat);
    apronMesh.rotation.x = -Math.PI / 2;
    apronMesh.position.y = -0.02;
    this.scene.add(apronMesh);

    // 3. Goals (Left & Right)
    this.createGoal(-this.PITCH_L / 2 + 1.2, 1);
    this.createGoal(this.PITCH_L / 2 - 1.2, -1);

    // 4. Advertising LED Boards
    this.createAdBoards();

    // 5. Stadium Grandstands with Crowd
    this.createGrandstands();
  }

  private createGoal(x: number, direction: number) {
    const goalGroup = new THREE.Group();
    const postMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.2, metalness: 0.6 });
    const postGeo = new THREE.CylinderGeometry(0.08, 0.08, this.GOAL_H, 12);

    // Left post
    const post1 = new THREE.Mesh(postGeo, postMat);
    post1.position.set(0, this.GOAL_H / 2, -this.GOAL_W / 2);
    post1.castShadow = !this.isSoftwareGl;
    goalGroup.add(post1);

    // Right post
    const post2 = new THREE.Mesh(postGeo, postMat);
    post2.position.set(0, this.GOAL_H / 2, this.GOAL_W / 2);
    post2.castShadow = !this.isSoftwareGl;
    goalGroup.add(post2);

    // Crossbar
    const crossbarGeo = new THREE.CylinderGeometry(0.08, 0.08, this.GOAL_W, 12);
    const crossbar = new THREE.Mesh(crossbarGeo, postMat);
    crossbar.rotation.x = Math.PI / 2;
    crossbar.position.set(0, this.GOAL_H, 0);
    crossbar.castShadow = !this.isSoftwareGl;
    goalGroup.add(crossbar);

    // Net (back box)
    const netDepth = 2.0;
    const netGeo = new THREE.BoxGeometry(netDepth, this.GOAL_H, this.GOAL_W);
    const netMat = new THREE.MeshBasicMaterial({
      color: 0xdddddd,
      wireframe: true,
      transparent: true,
      opacity: 0.25
    });
    const net = new THREE.Mesh(netGeo, netMat);
    net.position.set(-direction * (netDepth / 2), this.GOAL_H / 2, 0);
    goalGroup.add(net);

    goalGroup.position.set(x, 0, 0);
    this.scene.add(goalGroup);
  }

  private createAdBoards() {
    const boardMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.4,
      metalness: 0.3
    });

    const longBoardGeo = new THREE.BoxGeometry(this.PITCH_L + 2, 0.9, 0.3);
    const topBoard = new THREE.Mesh(longBoardGeo, boardMat);
    topBoard.position.set(0, 0.45, -this.PITCH_W / 2 - 2);
    this.scene.add(topBoard);

    const bottomBoard = new THREE.Mesh(longBoardGeo, boardMat);
    bottomBoard.position.set(0, 0.45, this.PITCH_W / 2 + 2);
    this.scene.add(bottomBoard);
  }

  private createGrandstands() {
    // 4 Grandstands surrounding the pitch
    const standMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.8 });
    const crowdMat1 = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    const crowdMat2 = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
    const crowdMat3 = new THREE.MeshBasicMaterial({ color: 0xef4444 });

    // North & South Stands
    const northStandGeo = new THREE.BoxGeometry(this.PITCH_L + 10, 8, 12);
    const northStand = new THREE.Mesh(northStandGeo, standMat);
    northStand.position.set(0, 4, -this.PITCH_W / 2 - 9);
    northStand.rotation.x = 0.2;
    this.scene.add(northStand);

    const southStand = new THREE.Mesh(northStandGeo, standMat);
    southStand.position.set(0, 4, this.PITCH_W / 2 + 9);
    southStand.rotation.x = -0.2;
    this.scene.add(southStand);

    // Populate animated spectator crowds using small colored boxes
    const spectatorGeo = new THREE.BoxGeometry(0.4, 0.6, 0.4);
    for (let i = 0; i < 40; i++) {
      const mat = i % 3 === 0 ? crowdMat1 : i % 3 === 1 ? crowdMat2 : crowdMat3;
      const spec = new THREE.Mesh(spectatorGeo, mat);
      spec.position.set(
        (Math.random() - 0.5) * (this.PITCH_L - 10),
        5 + Math.random() * 3,
        -this.PITCH_W / 2 - 7 - Math.random() * 4
      );
      this.scene.add(spec);

      const spec2 = new THREE.Mesh(spectatorGeo, mat);
      spec2.position.set(
        (Math.random() - 0.5) * (this.PITCH_L - 10),
        5 + Math.random() * 3,
        this.PITCH_W / 2 + 7 + Math.random() * 4
      );
      this.scene.add(spec2);
    }
  }

  private createBall() {
    // 3D Football with standard pentagon/hexagon look via procedural textures
    const ballCanvas = document.createElement('canvas');
    ballCanvas.width = 256;
    ballCanvas.height = 256;
    const ctx = ballCanvas.getContext('2d')!;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, 256, 256);
    ctx.fillStyle = '#111827';
    // Draw classic spots
    for (let x = 32; x < 256; x += 64) {
      for (let y = 32; y < 256; y += 64) {
        ctx.beginPath();
        ctx.arc(x, y, 14, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    const ballTex = new THREE.CanvasTexture(ballCanvas);
    ballTex.colorSpace = THREE.SRGBColorSpace;

    const ballGeo = new THREE.SphereGeometry(0.32, 16, 16);
    const ballMat = new THREE.MeshStandardMaterial({
      map: ballTex,
      roughness: 0.3,
      metalness: 0.1
    });

    this.ballMesh = new THREE.Mesh(ballGeo, ballMat);
    this.ballMesh.castShadow = !this.isSoftwareGl;
    this.ballMesh.position.copy(this.ballPos);
    this.scene.add(this.ballMesh);

    // Ball contact shadow on pitch
    const shadowGeo = new THREE.CircleGeometry(0.35, 16);
    const shadowMat = new THREE.MeshBasicMaterial({
      color: 0x000000,
      transparent: true,
      opacity: 0.45,
      depthWrite: false
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = 0.015;
    this.scene.add(shadowMesh);

    // Keep reference on ballMesh for shadow sync
    this.ballMesh.userData.shadow = shadowMesh;
  }

  /**
   * Builds a procedural 3D cartoon footballer (3-12 parts: head, hair, torso, shorts, legs, boots, arms)
   */
  private createCharacterMesh(
    kitPrimaryHex: string,
    kitSecondaryHex: string,
    skinHex: string,
    hairHex: string,
    kitNumber: number,
    isUser: boolean
  ): { group: THREE.Group; legs: [THREE.Mesh, THREE.Mesh]; arms: [THREE.Mesh, THREE.Mesh]; head: THREE.Mesh } {
    const group = new THREE.Group();

    const skinMat = new THREE.MeshStandardMaterial({ color: skinHex, roughness: 0.8 });
    const jerseyMat = new THREE.MeshStandardMaterial({ color: kitPrimaryHex, roughness: 0.6 });
    const shortsMat = new THREE.MeshStandardMaterial({ color: kitSecondaryHex, roughness: 0.6 });
    const hairMat = new THREE.MeshStandardMaterial({ color: hairHex, roughness: 0.9 });
    const bootMat = new THREE.MeshStandardMaterial({
      color: isUser ? this.userPlayer.appearance.bootsColor || '#f59e0b' : '#111827',
      roughness: 0.4
    });

    // 1. Torso / Jersey (stylized box with tapered look)
    const torsoGeo = new THREE.BoxGeometry(0.75, 0.95, 0.45);
    const torso = new THREE.Mesh(torsoGeo, jerseyMat);
    torso.position.y = 1.35;
    torso.castShadow = !this.isSoftwareGl;
    group.add(torso);

    // 2. Head (cartoon rounded box or sphere)
    const headGeo = new THREE.BoxGeometry(0.5, 0.52, 0.5);
    const head = new THREE.Mesh(headGeo, skinMat);
    head.position.y = 2.05;
    head.castShadow = !this.isSoftwareGl;
    group.add(head);

    // 3. Hair (volume piece on top of head)
    const hairGeo = new THREE.BoxGeometry(0.54, 0.22, 0.54);
    const hair = new THREE.Mesh(hairGeo, hairMat);
    hair.position.set(0, 2.32, 0);
    group.add(hair);

    // 4. Shorts
    const shortsGeo = new THREE.BoxGeometry(0.72, 0.45, 0.44);
    const shorts = new THREE.Mesh(shortsGeo, shortsMat);
    shorts.position.y = 0.88;
    group.add(shorts);

    // 5. Left & Right Legs
    const legGeo = new THREE.BoxGeometry(0.24, 0.75, 0.24);
    const leftLeg = new THREE.Mesh(legGeo, skinMat);
    leftLeg.position.set(-0.2, 0.45, 0);
    leftLeg.castShadow = !this.isSoftwareGl;
    group.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, skinMat);
    rightLeg.position.set(0.2, 0.45, 0);
    rightLeg.castShadow = !this.isSoftwareGl;
    group.add(rightLeg);

    // 6. Football Boots
    const bootGeo = new THREE.BoxGeometry(0.26, 0.16, 0.4);
    const leftBoot = new THREE.Mesh(bootGeo, bootMat);
    leftBoot.position.set(0, -0.38, 0.06);
    leftLeg.add(leftBoot);

    const rightBoot = new THREE.Mesh(bootGeo, bootMat);
    rightBoot.position.set(0, -0.38, 0.06);
    rightLeg.add(rightBoot);

    // 7. Arms
    const armGeo = new THREE.BoxGeometry(0.18, 0.7, 0.18);
    const leftArm = new THREE.Mesh(armGeo, skinMat);
    leftArm.position.set(-0.48, 1.3, 0);
    group.add(leftArm);

    const rightArm = new THREE.Mesh(armGeo, skinMat);
    rightArm.position.set(0.48, 1.3, 0);
    group.add(rightArm);

    // 8. Ground Contact Shadow Disc
    const shadowGeo = new THREE.CircleGeometry(0.5, 12);
    const shadowMat = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.35, depthWrite: false });
    const shadow = new THREE.Mesh(shadowGeo, shadowMat);
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.y = 0.015;
    group.add(shadow);

    // User player halo ring indicator
    if (isUser) {
      const ringGeo = new THREE.RingGeometry(0.65, 0.78, 24);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b, side: THREE.DoubleSide });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = -Math.PI / 2;
      ring.position.y = 0.02;
      group.add(ring);
    }

    return {
      group,
      legs: [leftLeg, rightLeg],
      arms: [leftArm, rightArm],
      head
    };
  }

  private spawnTeams() {
    this.actors = [];

    // Home Team (User's team: e.g. Estoril Academy or current club)
    // Formation: 1 GK, 2 DEF, 2 MID, 1 ATT (User) = 6 players on pitch for fluid 60fps
    const homeKitPrimary = this.homeClub.primaryColor || '#f59e0b';
    const homeKitSecondary = this.homeClub.secondaryColor || '#1e3a8a';

    const awayKitPrimary = this.awayClub.primaryColor || '#1d4ed8';
    const awayKitSecondary = this.awayClub.secondaryColor || '#ffffff';

    // 1. User's Footballer (Hero Striker/Attacker)
    const userVisuals = this.createCharacterMesh(
      homeKitPrimary,
      homeKitSecondary,
      this.userPlayer.appearance.skinTone,
      this.userPlayer.appearance.hairColor,
      this.userPlayer.kitNumber,
      true
    );
    const userActor: Actor3D = {
      mesh: userVisuals.group,
      position: new THREE.Vector3(-4, 0, 0),
      velocity: new THREE.Vector3(0, 0, 0),
      targetPos: new THREE.Vector3(-4, 0, 0),
      isHomeTeam: true,
      isPlayer: true,
      isGoalkeeper: false,
      role: 'ATT',
      number: this.userPlayer.kitNumber,
      name: this.userPlayer.kitName,
      speed: 6.2 + (this.userPlayer.attributes.pace / 100) * 3.5,
      kickCooldown: 0,
      tackleTimer: 0,
      animPhase: 0,
      legs: userVisuals.legs,
      arms: userVisuals.arms,
      head: userVisuals.head
    };
    userActor.mesh.position.copy(userActor.position);
    this.scene.add(userActor.mesh);
    this.actors.push(userActor);
    this.playerActor = userActor;

    // 2. Home AI Teammates
    const homePositions: { role: 'GK' | 'DEF' | 'MID' | 'ATT'; pos: [number, number]; num: number; name: string }[] = [
      { role: 'GK', pos: [-this.PITCH_L / 2 + 3, 0], num: 1, name: 'Diogo Costa' },
      { role: 'DEF', pos: [-24, -12], num: 3, name: 'Pepe Jr' },
      { role: 'DEF', pos: [-24, 12], num: 4, name: 'Ruben D.' },
      { role: 'MID', pos: [-12, -8], num: 8, name: 'Bruno F.' },
      { role: 'MID', pos: [-12, 8], num: 10, name: 'Bernardo' }
    ];

    homePositions.forEach((hp) => {
      const char = this.createCharacterMesh(homeKitPrimary, homeKitSecondary, '#d97706', '#1e293b', hp.num, false);
      const actor: Actor3D = {
        mesh: char.group,
        position: new THREE.Vector3(hp.pos[0], 0, hp.pos[1]),
        velocity: new THREE.Vector3(0, 0, 0),
        targetPos: new THREE.Vector3(hp.pos[0], 0, hp.pos[1]),
        isHomeTeam: true,
        isPlayer: false,
        isGoalkeeper: hp.role === 'GK',
        role: hp.role,
        number: hp.num,
        name: hp.name,
        speed: 6.0,
        kickCooldown: 0,
        tackleTimer: 0,
        animPhase: Math.random() * Math.PI,
        legs: char.legs,
        arms: char.arms,
        head: char.head
      };
      actor.mesh.position.copy(actor.position);
      this.scene.add(actor.mesh);
      this.actors.push(actor);
    });

    // 3. Away Opponents
    const awayPositions: { role: 'GK' | 'DEF' | 'MID' | 'ATT'; pos: [number, number]; num: number; name: string }[] = [
      { role: 'GK', pos: [this.PITCH_L / 2 - 3, 0], num: 1, name: 'Courtois' },
      { role: 'DEF', pos: [24, -12], num: 2, name: 'Carvajal' },
      { role: 'DEF', pos: [24, 12], num: 5, name: 'Rudiger' },
      { role: 'MID', pos: [12, -8], num: 6, name: 'Modric' },
      { role: 'MID', pos: [12, 8], num: 7, name: 'Valverde' },
      { role: 'ATT', pos: [6, 0], num: 9, name: 'Mbappé' }
    ];

    awayPositions.forEach((ap) => {
      const char = this.createCharacterMesh(awayKitPrimary, awayKitSecondary, '#f59e0b', '#0f172a', ap.num, false);
      const actor: Actor3D = {
        mesh: char.group,
        position: new THREE.Vector3(ap.pos[0], 0, ap.pos[1]),
        velocity: new THREE.Vector3(0, 0, 0),
        targetPos: new THREE.Vector3(ap.pos[0], 0, ap.pos[1]),
        isHomeTeam: false,
        isPlayer: false,
        isGoalkeeper: ap.role === 'GK',
        role: ap.role,
        number: ap.num,
        name: ap.name,
        speed: 6.0,
        kickCooldown: 0,
        tackleTimer: 0,
        animPhase: Math.random() * Math.PI,
        legs: char.legs,
        arms: char.arms,
        head: char.head
      };
      actor.mesh.position.copy(actor.position);
      this.scene.add(actor.mesh);
      this.actors.push(actor);
    });
  }

  /**
   * Main Physics & Match Update Step
   */
  public update(dt: number, input: MatchInputState) {
    if (this.matchStats.isGameOver) return;

    // Clamp dt to avoid tunnel physics
    const simDt = Math.min(dt, 0.05);

    // Update match time (90 minutes simulated over ~3 minutes of real time)
    this.matchTimerAccum += simDt;
    if (this.matchTimerAccum >= 1.8) {
      this.matchTimerAccum = 0;
      this.matchStats.matchTimeMinutes += 1;
      if (this.matchStats.matchTimeMinutes >= 90) {
        this.matchStats.isGameOver = true;
        this.matchStats.latestEventMessage = 'Fim da partida! 90 minutos completados.';
        sounds.playWhistle(true);
        if (this.onMatchEndCallback) {
          this.onMatchEndCallback(this.matchStats);
        }
      }
      this.onStateUpdate?.(this.matchStats);
    }

    // 1. Process User Player Controls
    if (this.playerActor) {
      const p = this.playerActor;

      // Calculate speed with sprint bonus
      let targetSpeed = p.speed;
      if (input.sprintHeld) {
        targetSpeed *= 1.35;
      }

      // Movement from joystick
      const jx = input.joystickVector.x;
      const jy = input.joystickVector.y;
      const len = Math.hypot(jx, jy);

      if (len > 0.1) {
        p.velocity.x = THREE.MathUtils.damp(p.velocity.x, jx * targetSpeed, 12, simDt);
        p.velocity.z = THREE.MathUtils.damp(p.velocity.z, jy * targetSpeed, 12, simDt);
        p.mesh.rotation.y = Math.atan2(jx, jy);
      } else {
        p.velocity.x = THREE.MathUtils.damp(p.velocity.x, 0, 14, simDt);
        p.velocity.z = THREE.MathUtils.damp(p.velocity.z, 0, 14, simDt);
      }

      // Tackle / Slide action
      if (input.tackleRequested && p.tackleTimer <= 0) {
        p.tackleTimer = 0.5;
        sounds.playTackle();
        p.velocity.x += Math.sin(p.mesh.rotation.y) * 8;
        p.velocity.z += Math.cos(p.mesh.rotation.y) * 8;
        this.matchStats.playerTackles += 1;
      }
      if (p.tackleTimer > 0) {
        p.tackleTimer -= simDt;
      }

      // User Shoot Action
      if (input.shootReleased && input.shootCharge > 0.05) {
        const hasPossession = this.ballPos.distanceTo(p.position) < 1.6;
        if (hasPossession) {
          this.executeShot(p, input.shootCharge);
          this.matchStats.playerShots += 1;
        }
      }

      // User Pass Action
      if (input.passRequested) {
        const hasPossession = this.ballPos.distanceTo(p.position) < 1.6;
        if (hasPossession) {
          this.executePass(p);
          this.matchStats.playerPasses += 1;
        }
      }

      // User Dribble Burst
      if (input.dribbleRequested) {
        const hasPossession = this.ballPos.distanceTo(p.position) < 1.6;
        if (hasPossession) {
          this.executeDribble(p);
        }
      }
    }

    // 2. Update Ball Physics
    this.updateBallPhysics(simDt);

    // 3. Update AI Actors (Teammates, Opponents, GKs)
    this.updateAI(simDt);

    // 4. Update Actor Positions & Leg Walking Animations
    this.updateActors(simDt);

    // 5. Check Goal & Boundary Events
    this.checkGoalsAndBounds();

    // 6. Camera Follow
    this.updateCamera(simDt);
  }

  private executeShot(shooter: Actor3D, powerRatio: number) {
    sounds.playKick(powerRatio);

    // Goal direction (towards right goal: x = PITCH_L / 2)
    const goalX = shooter.isHomeTeam ? this.PITCH_L / 2 : -this.PITCH_L / 2;
    // Add slight random dispersion based on shooting attribute
    const dispersion = (1 - (this.userPlayer.attributes.shooting / 100)) * (Math.random() - 0.5) * 4;
    const target = new THREE.Vector3(goalX, 1.2, dispersion);

    const shotDir = target.sub(this.ballPos).normalize();
    const speed = 20 + powerRatio * 22;

    this.ballVel.x = shotDir.x * speed;
    this.ballVel.y = Math.min(8, 2.5 + powerRatio * 6.5);
    this.ballVel.z = shotDir.z * speed;

    this.ballHolder = null;
    shooter.kickCooldown = 0.4;
  }

  private executePass(passer: Actor3D) {
    sounds.playKick(0.35);

    // Find closest teammate forward
    let bestTeammate: Actor3D | null = null;
    let bestScore = -9999;

    this.actors.forEach((a) => {
      if (a === passer || a.isHomeTeam !== passer.isHomeTeam || a.isGoalkeeper) return;
      const dist = a.position.distanceTo(passer.position);
      // Reward teammate in front
      const forwardness = passer.isHomeTeam ? (a.position.x - passer.position.x) : (passer.position.x - a.position.x);
      const score = forwardness * 2 - dist * 0.5;
      if (score > bestScore) {
        bestScore = score;
        bestTeammate = a;
      }
    });

    if (bestTeammate) {
      const target = (bestTeammate as Actor3D).position.clone();
      // Lead the pass
      target.x += (passer.isHomeTeam ? 2.5 : -2.5);
      const dir = target.sub(this.ballPos).normalize();
      const speed = 18;
      this.ballVel.x = dir.x * speed;
      this.ballVel.y = 0.8;
      this.ballVel.z = dir.z * speed;
    } else {
      // Default forward pass
      const fwd = passer.isHomeTeam ? 1 : -1;
      this.ballVel.x = fwd * 18;
      this.ballVel.y = 0.6;
      this.ballVel.z = 0;
    }

    this.ballHolder = null;
    passer.kickCooldown = 0.35;
  }

  private executeDribble(dribbler: Actor3D) {
    sounds.playTackle();
    // Quick burst forward and angle change
    const fwd = Math.sin(dribbler.mesh.rotation.y);
    const side = Math.cos(dribbler.mesh.rotation.y);

    dribbler.velocity.x += fwd * 4.5;
    dribbler.velocity.z += side * 4.5;

    this.ballVel.x += fwd * 5.5;
    this.ballVel.z += side * 5.5;
  }

  private updateBallPhysics(dt: number) {
    // Gravity
    this.ballVel.y -= 18 * dt;

    // Move ball
    this.ballPos.x += this.ballVel.x * dt;
    this.ballPos.y += this.ballVel.y * dt;
    this.ballPos.z += this.ballVel.z * dt;

    // Ground bounce and roll friction
    const ballRadius = 0.22;
    if (this.ballPos.y <= ballRadius) {
      this.ballPos.y = ballRadius;
      if (Math.abs(this.ballVel.y) > 0.8) {
        this.ballVel.y = -this.ballVel.y * 0.55;
      } else {
        this.ballVel.y = 0;
      }
      // Ground friction
      this.ballVel.x *= 0.982;
      this.ballVel.z *= 0.982;
    }

    // Air drag
    this.ballVel.x *= 0.995;
    this.ballVel.z *= 0.995;

    // Ball Mesh sync
    this.ballMesh.position.copy(this.ballPos);

    // Roll rotation
    const groundSpeed = Math.hypot(this.ballVel.x, this.ballVel.z);
    if (groundSpeed > 0.05) {
      this.ballMesh.rotation.z -= (this.ballVel.x * dt) / ballRadius;
      this.ballMesh.rotation.x += (this.ballVel.z * dt) / ballRadius;
    }

    // Ground shadow sync
    const shadow = this.ballMesh.userData.shadow as THREE.Mesh;
    if (shadow) {
      shadow.position.x = this.ballPos.x;
      shadow.position.z = this.ballPos.z;
      const heightFactor = Math.max(0.1, 1 - (this.ballPos.y - ballRadius) / 6);
      shadow.scale.setScalar(heightFactor);
      (shadow.material as THREE.MeshBasicMaterial).opacity = 0.45 * heightFactor;
    }
  }

  private updateAI(dt: number) {
    const ballX = this.ballPos.x;
    const ballZ = this.ballPos.z;

    this.actors.forEach((actor) => {
      if (actor.isPlayer) return;

      if (actor.kickCooldown > 0) {
        actor.kickCooldown -= dt;
      }

      const distToBall = actor.position.distanceTo(this.ballPos);

      // Goalkeeper logic
      if (actor.isGoalkeeper) {
        const goalLineX = actor.isHomeTeam ? -this.PITCH_L / 2 + 2.5 : this.PITCH_L / 2 - 2.5;
        actor.targetPos.x = goalLineX;
        // Clamp Z along goal mouth
        actor.targetPos.z = THREE.MathUtils.clamp(ballZ * 0.65, -this.GOAL_W / 2 + 0.5, this.GOAL_W / 2 - 0.5);

        // Goalkeeper dive / save if ball is approaching goal
        if (distToBall < 2.0 && actor.kickCooldown <= 0) {
          sounds.playKick(0.3);
          // Deflect or clear away
          const clearDir = actor.isHomeTeam ? 1 : -1;
          this.ballVel.x = clearDir * (12 + Math.random() * 6);
          this.ballVel.y = 3;
          this.ballVel.z = (Math.random() - 0.5) * 14;
          actor.kickCooldown = 0.8;
          this.matchStats.latestEventMessage = `Defesa incrível do guarda-redes ${actor.name}!`;
          this.onStateUpdate?.(this.matchStats);
        }
      }
      // Outfield AI (Teammates & Opponents)
      else {
        // Attackers & Midfielders press ball if nearby
        if (distToBall < 14) {
          actor.targetPos.x = ballX;
          actor.targetPos.z = ballZ;
        } else {
          // Return to tactical zone
          const baseX = actor.isHomeTeam ? -10 : 10;
          actor.targetPos.x = baseX + (actor.role === 'ATT' ? (actor.isHomeTeam ? 18 : -18) : 0);
        }

        // AI Ball touch / kick
        if (distToBall < 1.4 && actor.kickCooldown <= 0) {
          if (!actor.isHomeTeam) {
            // Opponent shoots if in range
            if (actor.position.x < -14 && Math.abs(actor.position.z) < 18) {
              this.executeShot(actor, 0.7);
            } else {
              this.executePass(actor);
            }
          } else {
            // Teammate passes to user if user calls for it or is in front
            if (this.playerActor && this.playerActor.position.x > actor.position.x) {
              this.executePass(actor);
            } else {
              this.executePass(actor);
            }
          }
        }
      }

      // Smooth move towards targetPos
      const dx = actor.targetPos.x - actor.position.x;
      const dz = actor.targetPos.z - actor.position.z;
      const dist = Math.hypot(dx, dz);

      if (dist > 0.4) {
        const moveSpeed = Math.min(actor.speed, dist * 3.5);
        actor.velocity.x = (dx / dist) * moveSpeed;
        actor.velocity.z = (dz / dist) * moveSpeed;
        actor.mesh.rotation.y = Math.atan2(dx, dz);
      } else {
        actor.velocity.x = THREE.MathUtils.damp(actor.velocity.x, 0, 8, dt);
        actor.velocity.z = THREE.MathUtils.damp(actor.velocity.z, 0, 8, dt);
      }
    });
  }

  private updateActors(dt: number) {
    this.actors.forEach((actor) => {
      // Position update
      actor.position.x += actor.velocity.x * dt;
      actor.position.z += actor.velocity.z * dt;

      // Keep within pitch boundaries
      actor.position.x = THREE.MathUtils.clamp(actor.position.x, -this.PITCH_L / 2 + 1, this.PITCH_L / 2 - 1);
      actor.position.z = THREE.MathUtils.clamp(actor.position.z, -this.PITCH_W / 2 + 1, this.PITCH_W / 2 - 1);

      actor.mesh.position.copy(actor.position);

      // Walking / Running leg and arm swing animation
      const speed = Math.hypot(actor.velocity.x, actor.velocity.z);
      if (speed > 0.2) {
        actor.animPhase += speed * dt * 3.2;
        const swing = Math.sin(actor.animPhase) * 0.45;
        actor.legs[0].rotation.x = swing;
        actor.legs[1].rotation.x = -swing;
        actor.arms[0].rotation.x = -swing;
        actor.arms[1].rotation.x = swing;
      } else {
        actor.legs[0].rotation.x = THREE.MathUtils.damp(actor.legs[0].rotation.x, 0, 10, dt);
        actor.legs[1].rotation.x = THREE.MathUtils.damp(actor.legs[1].rotation.x, 0, 10, dt);
        actor.arms[0].rotation.x = THREE.MathUtils.damp(actor.arms[0].rotation.x, 0, 10, dt);
        actor.arms[1].rotation.x = THREE.MathUtils.damp(actor.arms[1].rotation.x, 0, 10, dt);
      }

      // Ball dribbling touch: if player is right at ball, stick lightly
      const dToBall = actor.position.distanceTo(this.ballPos);
      if (dToBall < 1.1 && this.ballPos.y < 0.8 && actor.kickCooldown <= 0) {
        // Gentle nudge forward in facing direction
        const fwdX = Math.sin(actor.mesh.rotation.y);
        const fwdZ = Math.cos(actor.mesh.rotation.y);
        this.ballPos.x = actor.position.x + fwdX * 0.9;
        this.ballPos.z = actor.position.z + fwdZ * 0.9;
        this.ballVel.x = actor.velocity.x * 1.1;
        this.ballVel.z = actor.velocity.z * 1.1;
      }
    });
  }

  private checkGoalsAndBounds() {
    if (this.goalCooldown > 0) {
      this.goalCooldown -= 0.016;
      return;
    }

    const rightGoalLine = this.PITCH_L / 2 - 1.2;
    const leftGoalLine = -this.PITCH_L / 2 + 1.2;

    // 1. Goal Scored on Right Goal (Home Team Goal!)
    if (this.ballPos.x > rightGoalLine && Math.abs(this.ballPos.z) < this.GOAL_W / 2 && this.ballPos.y < this.GOAL_H) {
      this.matchStats.homeScore += 1;
      this.goalCooldown = 4.0;
      sounds.playGoalFanfare();
      sounds.playWhistle(false);

      const isUserGoal = this.playerActor && this.playerActor.position.distanceTo(this.ballPos) < 18;
      const scorer = isUserGoal ? this.userPlayer.kitName : 'Lisboa SC';
      if (isUserGoal) {
        this.matchStats.playerGoals += 1;
        this.matchStats.playerRating = Math.min(10, this.matchStats.playerRating + 1.2);
      }

      this.matchStats.latestEventMessage = `GOLOOOOOOOO! ${scorer} marca um golaço de levantar o estádio!`;
      this.onGoalScoredCallback(scorer, !!isUserGoal);
      this.onStateUpdate?.(this.matchStats);

      this.resetKickoff(false);
      return;
    }

    // 2. Goal Scored on Left Goal (Away Team Goal)
    if (this.ballPos.x < leftGoalLine && Math.abs(this.ballPos.z) < this.GOAL_W / 2 && this.ballPos.y < this.GOAL_H) {
      this.matchStats.awayScore += 1;
      this.goalCooldown = 4.0;
      sounds.playWhistle(false);

      this.matchStats.latestEventMessage = `Golo do ${this.awayClub.name}! O adversário empata a partida.`;
      this.onGoalScoredCallback(this.awayClub.name, false);
      this.onStateUpdate?.(this.matchStats);

      this.resetKickoff(true);
      return;
    }

    // 3. Goalpost or Crossbar strike
    const postThreshold = 0.35;
    if (
      Math.abs(this.ballPos.x - rightGoalLine) < postThreshold ||
      Math.abs(this.ballPos.x - leftGoalLine) < postThreshold
    ) {
      if (Math.abs(Math.abs(this.ballPos.z) - this.GOAL_W / 2) < postThreshold && this.ballPos.y < this.GOAL_H) {
        sounds.playWoodwork();
        this.ballVel.x = -this.ballVel.x * 0.7;
        this.matchStats.latestEventMessage = 'À TRAVE! Que tiro estrondoso ao poste!';
        this.onStateUpdate?.(this.matchStats);
      }
    }

    // 4. Out of bounds check
    if (Math.abs(this.ballPos.z) > this.PITCH_W / 2 + 1 || Math.abs(this.ballPos.x) > this.PITCH_L / 2 + 4) {
      // Reset ball to near pitch line
      this.ballPos.z = THREE.MathUtils.clamp(this.ballPos.z, -this.PITCH_W / 2 + 2, this.PITCH_W / 2 - 2);
      this.ballPos.x = THREE.MathUtils.clamp(this.ballPos.x, -this.PITCH_L / 2 + 6, this.PITCH_L / 2 - 6);
      this.ballPos.y = 0.22;
      this.ballVel.set(0, 0, 0);
    }
  }

  private resetKickoff(homeStarts: boolean) {
    this.ballPos.set(0, 0.22, 0);
    this.ballVel.set(0, 0, 0);
    this.actors.forEach((a) => {
      const baseX = a.isHomeTeam ? (a.isGoalkeeper ? -this.PITCH_L / 2 + 3 : -14) : (a.isGoalkeeper ? this.PITCH_L / 2 - 3 : 14);
      a.position.x = baseX;
      a.velocity.set(0, 0, 0);
    });
    if (this.playerActor) {
      this.playerActor.position.set(homeStarts ? -1 : -6, 0, 0);
    }
  }

  private updateCamera(dt: number) {
    if (!this.playerActor) return;

    // Camera smoothly trails user player and pans towards ball
    const targetX = this.playerActor.position.x + (this.ballPos.x - this.playerActor.position.x) * 0.35;
    const targetZ = this.playerActor.position.z + (this.ballPos.z - this.playerActor.position.z) * 0.35;

    this.cameraLookTarget.x = THREE.MathUtils.damp(this.cameraLookTarget.x, targetX, 5, dt);
    this.cameraLookTarget.y = 1.2;
    this.cameraLookTarget.z = THREE.MathUtils.damp(this.cameraLookTarget.z, targetZ, 5, dt);

    const desiredCamX = this.cameraLookTarget.x - 2;
    const desiredCamY = 14;
    const desiredCamZ = this.cameraLookTarget.z + 18;

    this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, desiredCamX, 4, dt);
    this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, desiredCamY, 4, dt);
    this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, desiredCamZ, 4, dt);

    this.camera.lookAt(this.cameraLookTarget);
  }

  private setupResizeListener() {
    window.addEventListener('resize', this.onResize);
  }

  private onResize = () => {
    if (!this.renderer || !this.camera || !this.container) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  private startLoop() {
    let lastTime = performance.now();

    const tick = () => {
      if (this.isDestroyed) return;

      const now = performance.now();
      const dt = (now - lastTime) / 1000;
      lastTime = now;

      this.renderer.render(this.scene, this.camera);

      if (this.isSoftwareGl) {
        // Software WebGL pacing as defined in Three.js skill
        const gl = this.renderer.getContext() as WebGL2RenderingContext;
        const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          if (this.isDestroyed) return;
          const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
          if (state === gl.UNSIGNALED) {
            this.animFrameId = window.setTimeout(poll, 5);
          } else {
            if (sync) gl.deleteSync(sync);
            this.animFrameId = window.setTimeout(tick, 80);
          }
        };
        this.animFrameId = window.setTimeout(poll, 5);
      } else {
        this.animFrameId = requestAnimationFrame(tick);
      }
    };

    if (this.isSoftwareGl) {
      this.animFrameId = window.setTimeout(tick, 10);
    } else {
      this.animFrameId = requestAnimationFrame(tick);
    }
  }

  public destroy() {
    this.isDestroyed = true;
    window.removeEventListener('resize', this.onResize);
    cancelAnimationFrame(this.animFrameId);
    clearTimeout(this.animFrameId);

    if (this.renderer) {
      this.renderer.dispose();
      if (this.container && this.renderer.domElement) {
        this.container.removeChild(this.renderer.domElement);
      }
    }
  }
}
